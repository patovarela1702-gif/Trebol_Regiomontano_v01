console.log("✅ app.js cargado correctamente");
// Version 10
// ===== Utilidades =====
// Selector rápido de un solo elemento
const $ = (q, r = document) => r.querySelector(q);
// Selector rápido de múltiples elementos (retorna array)
const $all = (q, r = document) => [...r.querySelectorAll(q)];

// Formato de moneda en pesos MXN
const peso = n => n.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' });

// Formato de fecha corta en español
const fdate = iso => new Date(iso).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' });

// Relleno de números con ceros a la izquierda
const pad = (n, l) => String(n).padStart(l, '0');
const pad5 = n => String(n).padStart(5, '0');

// Función para separar nombre y apellido
function splitName(full) {
    const p = String(full || '').trim().split(/\s+/);
    return {
        nombre: (p[0] || '').toUpperCase(),
        apellido: p.slice(1).join(' ').toUpperCase()
    };
}

// ===== Configuración fija y contactos =====
const PHONE_MAIN = "8187783678";
const PHONE_TICKET = "8131287162";
const PHONE_RECEIPT = "8131287162";
const SITE_TITLE = "Trébol Regiomontano";

// ===== Evento global para links internos =====
// Permite cambiar de vista en SPA con data-view
document.addEventListener('click', e => {
    const a = e.target.closest('[data-view]');
    if (!a) return;
    e.preventDefault();
    show(a.dataset.view);
});

// ===== Inicio =====
// Actualiza año en pie de página
document.getElementById('year').textContent = new Date().getFullYear();

// Actualiza título de marca
const brandEl = document.getElementById('brandTitle');
if (brandEl) brandEl.textContent = SITE_TITLE;

// Enlaces de WhatsApp
const waComprobante = $('#waComprobante');
if (waComprobante) waComprobante.href = 'https://wa.me/' + PHONE_RECEIPT;

const wa1 = $('#wa1');
if (wa1) { wa1.href = 'https://wa.me/' + PHONE_MAIN; wa1.textContent = '📲 +' + PHONE_MAIN; }

const waC1 = $('#waC1');
if (waC1) { waC1.href = 'https://wa.me/' + PHONE_MAIN; waC1.textContent = '📲 +' + PHONE_MAIN; }

// ===== Slider de imágenes =====
const images = [
  "chevy-colorado-2025.jpeg",
  "chevy-colorado-2025-2.jpg"
];
let currentIndex = 0;
const sliderImg = document.getElementById("slider-img");
const dots = document.querySelectorAll("#slider-dots span");

// Función para mostrar slide según índice
function showSlide(index) {
  currentIndex = index;
  if(currentIndex < 0) currentIndex = images.length - 1;
  if(currentIndex >= images.length) currentIndex = 0;

  sliderImg.src = images[currentIndex];

  // Actualizar dots activos
  dots.forEach((dot, i) => {
    if(i === currentIndex) dot.classList.add("active");
    else dot.classList.remove("active");
  });
}

// Botones de navegación
document.getElementById("prev-slide").addEventListener("click", () => {
  showSlide(currentIndex - 1);
});
document.getElementById("next-slide").addEventListener("click", () => {
  showSlide(currentIndex + 1);
});

// Dots clicables
dots.forEach(dot => {
  dot.addEventListener("click", () => {
    const i = parseInt(dot.getAttribute("data-i"));
    showSlide(i);
  });
});

// Mostrar primer slide al iniciar
showSlide(0);

// ==================================================================
// Bloque DOM Content Loader
// ==================================================================
window.addEventListener('DOMContentLoaded', () => {
    console.log("⚙️ DOMContentLoaded iniciado.");
    
    // Generar un ID único para identificar al usuario en backend
    let userId = sessionStorage.getItem('userId');
    if (!userId) {
       userId = crypto.randomUUID();
       sessionStorage.setItem('userId', userId);
    }

// Limpiar inputs y selects de usuario al cargar la página
const nombreInput = document.getElementById('nombreCliente');
const apellidoInput = document.getElementById('apellidoCliente');
const telefonoInput = document.getElementById('telefonoCliente');
const estadoSelect = document.getElementById('estadoCliente');

const ticketSearchInput = document.getElementById('ticketSearch');
const randomQtySelect = document.getElementById('randomQty');

if (nombreInput) nombreInput.value = '';
if (apellidoInput) apellidoInput.value = '';
if (telefonoInput) telefonoInput.value = '';
if (estadoSelect) estadoSelect.value = ''; // selecciona la opción vacía

if (ticketSearchInput) ticketSearchInput.value = '';
if (randomQtySelect) randomQtySelect.value = '1'; // valor por defecto


    // Habilitar botones de compartir por redes
    const waBtn = document.getElementById("waShare");
    const fbBtn = document.getElementById("fbShare");

    const shareData = {
        title: "Trébol Regiomontano 🍀",
        text: "Participa en las rifas de El Trébol Regiomontano 🎟️",
        url: window.location.href
    };

    waBtn.addEventListener("click", () => {
        const msg = encodeURIComponent(`${shareData.text} ${shareData.url}`);
        window.open(`https://wa.me/?text=${msg}`, "_blank");
    });

    fbBtn.addEventListener("click", () => {
        const u = encodeURIComponent(shareData.url);
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${u}`, "_blank");
    });

    // ===== Control de boletos propios del usuario =====
    let boletosPropios = JSON.parse(sessionStorage.getItem("boletosPropios") || "[]");


    // Elementos del DOM para boletos
    const numsContainer = document.getElementById('nums'); // Contenedor de boletos
    const selListEl = document.getElementById('selList'); // Lista de boletos seleccionados
    const totalEl = document.getElementById('total'); // Total calculado
    if (!numsContainer || !selListEl || !totalEl) return console.warn("⚠️ Elementos principales no encontrados.");

    // Mapeo de precios por cantidad (no se usa directamente)
    const priceMap = { 1: 25, 5: 110, 10: 180, 100: 1800, 1000: 18000 };
    const totalTickets = 10000;
    const ticketWidth = 60;
    const ticketHeight = 40;

    // Función que calcula cuántos boletos caben por fila según ancho de ventana
    function getTicketsPerRow() {
        const w = window.innerWidth;
        if (w >= 1400) return 9;
        if (w >= 1024) return 8;
        if (w >= 768) return 7;
        return 6;
    }

    let ticketsPerRow = getTicketsPerRow();
    const rowsPerPage = 13;
    let ticketsPerPage = rowsPerPage * ticketsPerRow;
    let currentPage = 0;
    let selectedNums = []; // Array con boletos seleccionados

    // Recalcular layout al cambiar tamaño de ventana
    window.addEventListener('resize', () => {
        const newPerRow = getTicketsPerRow();
        if (newPerRow !== ticketsPerRow) {
            ticketsPerRow = newPerRow;
            ticketsPerPage = rowsPerPage * ticketsPerRow;
            renderTicketsPage();
        }
    });

    // Inicializa boletos
    let tickets = Array.from({ length: totalTickets }, (_, i) => ({
        numero: String(i + 1).padStart(5, '0'),
        estado: 'disponible'
    })).filter(t => t.numero !== '00000'); // Filtra boleto "00000" que no existe

    // Configura contenedor de scroll
    numsContainer.style.position = 'relative';
    numsContainer.style.overflowY = 'auto';

    // ===== Fetch del estado de boletos =====
async function fetchTicketStatus() {
    try {
        console.log("📡 Cargando estado de boletos...");
        const res = await fetch('https://qnsaexubyc.execute-api.us-east-2.amazonaws.com/dev_publico/boletos-publico-00?ids=plet0rikan', { cache: 'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const raw = await res.json();
        const list = Array.isArray(raw) ? raw : (Array.isArray(raw.list) ? raw.list : []);
        const estadoMap = Object.create(null);

        // Obtener userId de la sesión
        const userId = sessionStorage.getItem('userId');

        // Mapear estado y dueño de cada boleto
        for (const d of list) {
            const rawNum = d.numero_boleto ?? d.numero ?? d.numeroBoleto ?? d.id ?? '';
            const num = String(rawNum).replace(/\D/g, '').padStart(5, '0');
            const estado = (d.disponibilidad ?? d.estado ?? d.status ?? 'disponible').trim().toLowerCase();
            const ownerId = d.user_id ?? null; // suponer que tu API devuelve user_id

            if (num) estadoMap[num] = { estado, ownerId };
        }

        // Limpiar selección actual y actualizar tickets
        selectedNums = [];

        tickets.forEach(t => {
            const info = estadoMap[t.numero];
            if (!info) {
                t.estado = 'disponible';
            } else {
                t.estado = info.estado;
                // Solo añadir a selectedNums si el boleto es tuyo
                if (t.estado === 'seleccionado' && info.ownerId === userId) {
                    selectedNums.push(t.numero);
                }
            }
        });

        renderTicketsPage();
        updateSelection();
        console.log("✅ Estado de boletos actualizado correctamente y selección reflejada.");
    } catch (err) {
        console.error('❌ No se pudo cargar el estado de boletos:', err);
        tickets.forEach(t => { t.estado = t.estado || 'disponible'; });
        renderTicketsPage();
        updateSelection();
    }
}


    fetchTicketStatus();

    // ===== Renderizar página de boletos =====
    function renderTicketsPage() {
        numsContainer.innerHTML = '';
        const startIndex = currentPage * ticketsPerPage;
        const pageTickets = tickets.slice(startIndex, startIndex + ticketsPerPage);

        pageTickets.forEach((t, idx) => {
            const row = Math.floor(idx / ticketsPerRow);
            const col = idx % ticketsPerRow;

            const div = document.createElement('div');
            div.className = 'num';
            div.textContent = t.numero;
            div.style.position = 'absolute';
            div.style.width = `${ticketWidth - 4}px`;
            div.style.height = `${ticketHeight - 4}px`;
            div.style.left = `${col * ticketWidth}px`;
            div.style.top = `${row * ticketHeight}px`;
            div.style.boxSizing = 'border-box';
            div.style.border = '1px solid #ccc';
            div.style.display = 'flex';
            div.style.alignItems = 'center';
            div.style.justifyContent = 'center';
            div.style.userSelect = 'none';
            div.style.cursor = t.estado === 'disponible' ? 'pointer' : 'not-allowed';
            div.style.opacity = t.estado === 'disponible' ? '1' : '0.5';
            if (selectedNums.includes(t.numero)) div.classList.add('sel');
            numsContainer.appendChild(div);
        });

        numsContainer.style.width = `${ticketsPerRow * ticketWidth}px`;
        numsContainer.style.height = `${rowsPerPage * ticketHeight}px`;
        updatePaginationButtons();
    }

    // ===== Botones de paginación =====
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');
    const pageInfo = document.getElementById('pageInfo');

    function updatePaginationButtons() {
        const totalPages = Math.ceil(tickets.length / ticketsPerPage);
        pageInfo.textContent = `Página ${currentPage + 1} / ${totalPages}`;
        prevPageBtn.disabled = currentPage === 0;
        nextPageBtn.disabled = currentPage >= totalPages - 1;
    }

    prevPageBtn.addEventListener('click', () => { if (currentPage > 0) { currentPage--; renderTicketsPage(); } });
    nextPageBtn.addEventListener('click', () => { const totalPages = Math.ceil(tickets.length / ticketsPerPage); if (currentPage < totalPages - 1) { currentPage++; renderTicketsPage(); } });

    // ===== Actualizar estado de boleto en backend =====
    async function actualizarBoleto(numero, nuevoEstado) {
    console.log(`🎟️ Actualizando boleto ${numero} → ${nuevoEstado}`);
    const API_URL = "https://gjhv634ve7.execute-api.us-east-2.amazonaws.com/ticketblock-00/boletos-publico-00";

    try {
        // Enviar sessionId al backend para identificar al usuario
        const body = {
	    id: numero,
	    estado: nuevoEstado,
	    userId: userId // siempre enviar userId, backend lo usa solo si está seleccionado
	};

        const res = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body)
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data.status === "ok" && Number(data.updatedRows) > 0) {
            const celda = [...document.querySelectorAll(".num")].find(el => el.textContent.trim() === numero);
            const boleto = tickets.find(t => t.numero === numero);
            if (!boleto || !celda) return;

            boleto.estado = nuevoEstado;

            // Marcar y recordar boletos propios del usuario en sessionStorage
            if (nuevoEstado === "seleccionado") {
                if (!boletosPropios.includes(numero)) boletosPropios.push(numero);
                sessionStorage.setItem("boletosPropios", JSON.stringify(boletosPropios));
            } else if (nuevoEstado === "disponible") {
                boletosPropios = boletosPropios.filter(n => n !== numero);
                sessionStorage.setItem("boletosPropios", JSON.stringify(boletosPropios));
            }

            // Actualizar UI
            if (nuevoEstado === "seleccionado") {
                celda.classList.add("sel");
                celda.style.opacity = "1";
                celda.dataset.userSelected = "1";
                if (!selectedNums.includes(numero)) selectedNums.push(numero);
            } else if (nuevoEstado === "disponible") {
                celda.classList.remove("sel");
                celda.style.opacity = "1";
                delete celda.dataset.userSelected;
                selectedNums = selectedNums.filter(n => n !== numero);
            } else {
                celda.classList.remove("sel");
                celda.style.opacity = "0.5";
                delete celda.dataset.userSelected;
            }

            updateSelection();
        } else console.warn(`⚠️ No se pudo actualizar el boleto ${numero}.`);
    } catch (err) {
        console.error("💥 Error al actualizar boleto:", err);
    }
}

    // ===== Click en boleto manual =====
    numsContainer.addEventListener("click", async e => {
        const btn = e.target.closest(".num");
        if (!btn) return;
        const numero = btn.textContent.trim();
        const boleto = tickets.find(t => t.numero === numero);
        if (!boleto) return;

        // ⚠️ No permitir seleccionar boletos de otros usuarios o ya vendidos/apartados
if (["vendido", "apartado", "seleccionado"].includes(boleto.estado) && !btn.dataset.userSelected) {
    alert("⛔ Este boleto no está disponible.");
    return;
}


// No permitir deseleccionar boletos que no sean del usuario
if (boleto.estado === "seleccionado" && !boletosPropios.includes(numero)) {
    alert("⛔ Este boleto fue seleccionado por otro usuario.");
    return;
}


        const nuevoEstado = boleto.estado === "disponible" ? "seleccionado"
                            : boleto.estado === "seleccionado" ? "disponible" : null;
        if (!nuevoEstado) return;

        await actualizarBoleto(numero, nuevoEstado);
    });

    // ===== Actualizar listado de selección =====
    function updateSelection() {
        if (selectedNums.length === 0) { selListEl.textContent = 'ninguno'; totalEl.textContent = '$0.00'; }
        else { selListEl.textContent = selectedNums.join(', '); totalEl.textContent = `$${(selectedNums.length * 25).toLocaleString()}.00`; }
    }

    // ===== Scroll hacia boleto específico =====
    function scrollToTicket(ticketNumber) {
        const index = tickets.findIndex(t => t.numero === ticketNumber);
        if (index === -1) { alert('Boleto no encontrado'); return; }
        currentPage = Math.floor(index / ticketsPerPage);
        renderTicketsPage();
        const indexInPage = index % ticketsPerPage;
        const row = Math.floor(indexInPage / ticketsPerRow);
        numsContainer.scrollTop = row * ticketHeight;
    }

    // ===== Botón Limpiar =====
    const clearBtn = document.getElementById('clearBtn');
    if (clearBtn) clearBtn.addEventListener('click', async () => {
        const boletosALiberar = [...selectedNums]; // Clonar array de seleccionados
        for (const num of boletosALiberar) await actualizarBoleto(num, "disponible"); // Liberar cada boleto
        selectedNums = []; // Limpiar array
        renderTicketsPage(); // Re-renderizar DOM
        updateSelection(); // Actualizar listado y total
        clearBtn.textContent = "Limpio ✅"; // Feedback al usuario
        setTimeout(() => (clearBtn.textContent = "Limpiar"), 1500);
    });

    // ===== Máquina de la Suerte (selección aleatoria) =====
    if (randomBtn && randomQty) {
        // Actualiza las opciones de cantidad según boletos disponibles
        function updateQtyOptions() {
            const availableCount = tickets.filter(t => t.estado === 'disponible' && !selectedNums.includes(t.numero)).length;
            [...randomQty.options].forEach(opt => {
                opt.disabled = Number(opt.value) > availableCount;
            });
        }
        updateQtyOptions();

        // Función que selecciona boletos aleatorios
        async function selectRandomTickets(qty) {
            console.log("🎲 selectRandomTickets llamado con qty =", qty);
            let available = tickets.filter(t => t.estado === 'disponible' && !selectedNums.includes(t.numero));
            if (!available.length) return console.warn("⚠️ No hay boletos disponibles para seleccionar");
            const toSelect = Math.min(qty, available.length);

            for (let i = 0; i < toSelect; i++) {
                const randIndex = Math.floor(Math.random() * available.length);
                const randTicket = available.splice(randIndex, 1)[0];

                // Asegurarse de renderizar página correcta
                const pageIndex = Math.floor(tickets.findIndex(t => t.numero === randTicket.numero) / ticketsPerPage);
                if (currentPage !== pageIndex) { currentPage = pageIndex; renderTicketsPage(); }

                await actualizarBoleto(randTicket.numero, 'seleccionado');
const btn = [...document.querySelectorAll(".num")].find(el => el.textContent.trim() === randTicket.numero);
if (btn) { 
    btn.classList.add('sel'); 
    btn.style.opacity = '1'; 
    btn.dataset.userSelected = "1"; 
}

// --- NUEVO: registrar en boletosPropios ---
if (!boletosPropios.includes(randTicket.numero)) boletosPropios.push(randTicket.numero);
sessionStorage.setItem("boletosPropios", JSON.stringify(boletosPropios));
// ------------------------------------------

if (!selectedNums.includes(randTicket.numero)) selectedNums.push(randTicket.numero);
scrollToTicket(randTicket.numero);

            }

            updateSelection();
            updateQtyOptions();
        }

        // Listener del botón Generar
        randomBtn.addEventListener('click', async () => {
            const qty = Number(randomQty.value);
            if (isNaN(qty) || qty <= 0) return console.selwarn('Cantidad inválida');
            await selectRandomTickets(qty);
        });

        // Si se hace click manualmente en un boleto, actualizar opciones
        numsContainer.addEventListener('click', () => updateQtyOptions());
    }

    // ===== Búsqueda de boleto =====
    const searchInput = document.getElementById('ticketSearch');
    const searchBtn = document.getElementById('ticketGo');
    if (searchInput && searchBtn) {
        searchBtn.addEventListener('click', () => {
            let value = searchInput.value.trim().replace(/\D/g, '');
            const num = parseInt(value, 10);
            if (isNaN(num) || num < 1 || num > totalTickets) return alert(`Boleto debe estar entre 1 y ${totalTickets}`);
            scrollToTicket(num.toString().padStart(5, '0'));
        });
        searchInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchBtn.click(); } });
    }

    // ===== Botón WhatsApp para comprar boletos =====
    const wantBtn = document.getElementById('wantBtn');
    if (wantBtn) wantBtn.addEventListener('click', e => {
        e.preventDefault();
        if (!selectedNums.length) return alert("Selecciona al menos un boleto 😄");

        const nombre = $('#nombreCliente')?.value.trim() || '';
        const apellido = $('#apellidoCliente')?.value.trim() || '';
        const telefono = $('#telefonoCliente')?.value.trim() || '';
        const estado = $('#estadoCliente')?.value.trim() || '';

        if (!nombre || !apellido || !/^\d{10}$/.test(telefono) || !estado) return alert("Completa todos los datos correctamente 😄");

        const mensaje = `¡Hola! Quiero comprar los siguientes boletos:\n${selectedNums.join(', ')}\nTotal: $${(selectedNums.length * 25).toLocaleString()}.00\nMis datos:\n- Nombre: ${nombre}\n- Apellido: ${apellido}\n- Teléfono: ${telefono}\n- Estado: ${estado}`;
        window.open(`https://wa.me/+8131287162?text=${encodeURIComponent(mensaje)}`, '_blank');
    });

// ===== Liberar boletos al salir de la página =====
window.addEventListener("beforeunload", () => {
    if (!selectedNums.length) return;

    try {
        const url = "https://gjhv634ve7.execute-api.us-east-2.amazonaws.com/ticketblock-00/boletos-publico-00";
        selectedNums.forEach(num => {
            const data = JSON.stringify({ id: num, estado: "disponible" });
            navigator.sendBeacon(url, data);
        });
        console.log("📤 Boletos liberados con sendBeacon:", selectedNums);
    } catch (err) {
        console.warn("⚠️ Error al liberar boletos con sendBeacon:", err);
    }
});



    renderTicketsPage();
    updateSelection();
});

