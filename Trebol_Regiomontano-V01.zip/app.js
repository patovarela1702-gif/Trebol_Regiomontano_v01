console.log("✅ app.js cargado correctamente");


// ===== Utilidades =====
const $ = (q, r = document) => r.querySelector(q);
const $all = (q, r = document) => [...r.querySelectorAll(q)];
const peso = n => n.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' });
const fdate = iso => new Date(iso).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' });
const pad = (n, l) => String(n).padStart(l, '0');
const pad5 = n => String(n).padStart(5, '0');

function splitName(full) {
    const p = String(full || '').trim().split(/\s+/);
    return {
        nombre: (p[0] || '').toUpperCase(),
        apellido: p.slice(1).join(' ').toUpperCase()
    };
}

// ===== Configuración fija y contactos =====
const PHONE_MAIN = "8187783678";
const PHONE_TICKET = "8131287162";
const PHONE_RECEIPT = "8131287162";
const SITE_TITLE = "Trébol Regiomontano";

// ===== Evento global para links internos =====
document.addEventListener('click', e => {
    const a = e.target.closest('[data-view]');
    if (!a) return;
    e.preventDefault();
    show(a.dataset.view);
});

// ===== Inicio =====
document.getElementById('year').textContent = new Date().getFullYear();

const brandEl = document.getElementById('brandTitle');
if (brandEl) brandEl.textContent = SITE_TITLE;

const waComprobante = $('#waComprobante');
if (waComprobante) waComprobante.href = 'https://wa.me/' + PHONE_RECEIPT;

const wa1 = $('#wa1');
if (wa1) { wa1.href = 'https://wa.me/' + PHONE_MAIN; wa1.textContent = '📲 +' + PHONE_MAIN; }

const waC1 = $('#waC1');
if (waC1) { waC1.href = 'https://wa.me/' + PHONE_MAIN; waC1.textContent = '📲 +' + PHONE_MAIN; }


  const firstImg=r=> (r?.images?.length?r.images[0]:(r?.img||''));

  // ===== Datos (desde admin / localStorage) =====
  const DBKEY='trebolDB_v1';
  const readDB=()=>{ try{ return JSON.parse(localStorage.getItem(DBKEY)||'{}') }catch{ return {} } };

  // Categorías
  const CATEGORIES=[{id:"all",name:"Todas"},{id:"autos",name:"Autos"},{id:"motos",name:"Motos"},{id:"efectivo",name:"Efectivo"},{id:"electro",name:"Electrónica"}];

  // Texto demo reutilizable
  const LONG_COLORADO = `
    <div class="title-md">🏆 PREMIOS 🏆</div>
    <div class="small muted" style="margin:6px 0"><b>1º Lugar - AUDI Q8 2025 + BONOS 🎁</b></div>
    <div class="panel" style="margin:10px auto;max-width:720px">
      <div><b>PRE-EVENTO</b> — $5,000 <i>FECHA POR ANUNCIARSE</i></div>
      <div><b>PRE-EVENTO</b> — $5,000 <i>FECHA POR ANUNCIARSE</i></div>
    </div>
    <p class="muted" style="margin:8px 0">
      🍀 Evento Realizado en base a Lotería Nacional 🍀<br>
      🚨 20:00 Hora CDMX 🚨<br>
      🎫 99,999 Emisiones 🎫
    </p>
    <div class="title-md" style="margin-top:10px">🎟 BOLETOS</div>
    <div class="grid-2-compact small" style="margin-top:6px;max-width:720px;margin-left:auto;margin-right:auto">
      <div>1 boleto</div><div class="mono">$15 mxn</div>
      <div>5 boletos</div><div class="mono">$70 mxn</div>
      <div>10 boletos</div><div class="mono">$140 mxn</div>
      <div>100 boletos</div><div class="mono">$1,400 mxn</div>
      <div>1000 boletos</div><div class="mono">$14,000 mxn</div>
      </div>
  `;
  function basicInfo(nombre){return `<div class="title-md">🏆 PREMIOS 🏆</div><div class="small muted" style="margin:6px 0">1º Lugar — ${nombre}</div>`}

  // Adaptador: rifas guardadas en admin -> objeto usado aquí
  const mapR = r => ({
    id: r.id,
    title: r.name,
    categoryId: r.categoryId || 'autos',
    price: Number(r.price||0),
    drawDate: r.drawDate || r.endDate || new Date().toISOString().slice(0,10),
    drawTime: r.drawTime || '20:00',
    shortDesc: r.shortDesc || '',
    maxNumbers: Number(r.totalTickets||100000),
    images: r.images || [],
    img: (r.images && r.images[0]) || '',
    longInfo: r.longInfo || '',
    sold: r.sold || [],
    progress: r.progress || 0,
    orders: r.orders || []
  });

  // Respaldo por si no hay nada en localStorage
  const RAFFLES_DEFAULT=[
    /* {id:"r1",title:"Ford Bronco 2025",img:"Ford-Bronco.jpg",categoryId:"autos",price:25,drawDate:"2025-12-31",drawTime:"21:00",shortDesc:"Premio de lujo.",maxNumbers:100000,sold:[],progress:0,longInfo:basicInfo("FORD BRONCO 2025"),orders:[]}, */
    {id:"r2",title:"Chevrolet Colorado 2025",categoryId:"autos",price:25,drawDate:"2025-12-16",drawTime:"20:00",shortDesc:"Lujo y performance, todo en uno.",maxNumbers:10000,sold:[0],progress:0,
      images:["chevy-colorado-2025.jpeg","audi-q8-2.jpg","audi-q8-3.jpg","audi-q3-2025.jpg"], longInfo: LONG_COLORADO, orders:[]},
    /* {id:"r3",title:"Nissan GTR R35 2025",img:"gtr-r35.jpg",categoryId:"autos",price:25,drawDate:"2025-12-31",drawTime:"21:00",shortDesc:"Tecnología tope de gama.",maxNumbers:100000,sold:[],progress:0,longInfo:basicInfo("NISSAN GTR R35 2025"),orders:[]}, */
  ];

  function loadRaffles(){
    const db=readDB();
    const arr = Array.isArray(db.raffles) ? db.raffles.map(mapR) : [];
    return arr.length ? arr : RAFFLES_DEFAULT;
  }
  const RAFFLES = loadRaffles();

  // También traemos título del sitio y WhatsApp principal desde Config
  const DB_NOW = readDB();


// Destacados (3 rifas más próximas y activas)
const featuredEl = $('#featured');

function renderFeatured(){
  if(!featuredEl) return;

  const now = new Date();

  // Carga rifas del admin (localStorage) o usa las embebidas como respaldo
  let list = [];
  try {
    const saved = JSON.parse(localStorage.getItem('raffles') || '[]');
    list = Array.isArray(saved) && saved.length ? saved : RAFFLES;
  } catch {
    list = RAFFLES;
  }

  // Filtra activas y dentro de fechas; ordena por la fecha más cercana
  const xs = list
    .filter(r => (r.active ?? true))
    .filter(r => !r.startDate || new Date(r.startDate) <= now)
    .filter(r => !r.endDate   || new Date(r.endDate)   >= now)
    .sort((a,b) => +new Date(a.drawDate || a.endDate || a.startDate || '2100-01-01')
                 - +new Date(b.drawDate || b.endDate || b.startDate || '2100-01-01'))
    .slice(0,3); // cambia a 6 si quieres mostrar 6

  featuredEl.innerHTML = xs.map(r => `
    <div class="panel" style="width: fit-content;">
      <a href="rifa0.html"> <img src="${firstImg(r)}" alt="${r.title}" class="shadow"
           style="height:160px;object-fit:cover;border-radius:10px" loading="lazy"></a>
      <div class="small muted" style="margin-top:6px">
        ${fdate(r.drawDate || r.endDate || r.startDate || new Date())}
      </div>
      <div class="title-md" style="font-weight:800">${r.title}</div>
    </div>
  `).join('');
}

renderFeatured();

// ========================
// Boton enviar formulario en Contactos
// ========================
document.addEventListener('DOMContentLoaded', () => {
  const ctSend = document.getElementById('ctSend');
  if(!ctSend) return;

  ctSend.addEventListener('click', e => {
    e.preventDefault();

    const name  = document.getElementById('ctName').value.trim();
    const email = document.getElementById('ctEmail').value.trim();
    const phone = document.getElementById('ctPhone').value.trim();
    const msg   = document.getElementById('ctMsg').value.trim();

    if(!name || !email || !msg){
      alert('Por favor llena nombre, correo y mensaje.');
      return;
    }

    const subject = encodeURIComponent('Nuevo mensaje desde formulario');
    const body = encodeURIComponent(
      `Nombre: ${name}\nCorreo: ${email}\nTeléfono: ${phone}\nMensaje:\n${msg}`
    );

    window.location.href = `mailto:contacto@trebolregiomontano.com?subject=${subject}&body=${body}`;
  });
});


// ========================
// Copiar datos bancarios
// ========================
document.body.addEventListener('click', e=>{
    const btn = e.target.closest('.copy'); if(!btn) return;
    const val = btn.dataset.val;
    const ta = document.createElement('textarea');
    ta.value = val; ta.style.position='fixed'; ta.style.top='-1000px';
    document.body.appendChild(ta); ta.focus(); ta.select();
    try{ const ok = document.execCommand('copy'); console.log(ok?'✅ Copiado':'❌ No copiado',val); }
    catch(err){ console.error('Error al copiar:',err); }
    document.body.removeChild(ta);
    const original = btn.textContent; btn.textContent='¡Copiado!'; btn.disabled=true;
    setTimeout(()=>{ btn.textContent=original; btn.disabled=false; },1200);
});

