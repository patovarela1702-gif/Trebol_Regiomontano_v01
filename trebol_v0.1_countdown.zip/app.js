document.addEventListener('DOMContentLoaded', function () {
  var tz = 'America/Monterrey';
  function zonedDate(y, m, d, hh, mm) {
    var utcGuess = Date.UTC(y, m - 1, d, hh, mm, 0);
    var fmt = new Intl.DateTimeFormat('en-US', { timeZone: tz, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    var parts = fmt.formatToParts(new Date(utcGuess));
    var map = {};
    for (var i = 0; i < parts.length; i++) map[parts[i].type] = parts[i].value;
    var guessUTC = Date.UTC(+map.year, +map.month - 1, +map.day, +map.hour, +map.minute, +map.second);
    var desiredUTC = Date.UTC(y, m - 1, d, hh, mm, 0);
    return new Date(utcGuess + (desiredUTC - guessUTC));
  }

  var target = zonedDate(2025, 10, 31, 20, 30);

  var sub = document.querySelector('.cd-subtitle');
  if (sub && typeof Intl !== 'undefined') {
    var dtf = new Intl.DateTimeFormat('es-MX', { timeZone: tz, weekday: 'long', day: '2-digit', month: 'long', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
    sub.textContent = 'Termina el ' + dtf.format(target) + ' (Monterrey)';
  }

  var dEl = document.getElementById('d');
  var hEl = document.getElementById('h');
  var mEl = document.getElementById('m');
  var sEl = document.getElementById('s');
  if (!(dEl && hEl && mEl && sEl)) return;

  function pad(n) { return String(n).padStart(2, '0'); }

  function tick() {
    var now = new Date();
    var diff = target - now;
    if (diff <= 0) {
      dEl.textContent = '00';
      hEl.textContent = '00';
      mEl.textContent = '00';
      sEl.textContent = '00';
      clearInterval(timer);
      return;
    }
    var s = Math.floor(diff / 1000);
    var days = Math.floor(s / 86400); s -= days * 86400;
    var hours = Math.floor(s / 3600); s -= hours * 3600;
    var mins = Math.floor(s / 60); var secs = s - mins * 60;

    dEl.textContent = pad(days);
    hEl.textContent = pad(hours);
    mEl.textContent = pad(mins);
    sEl.textContent = pad(secs);
  }

  var timer = setInterval(tick, 1000);
  tick();
});